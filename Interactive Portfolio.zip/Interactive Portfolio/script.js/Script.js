
// Get references to the button and body
const toggleButton = document.getElementById('mode-toggle');
const body = document.body;

// Add click event to toggle classes
toggleButton.addEventListener('click', () => {
  body.classList.toggle('dark-mode');
  body.classList.toggle('light-mode');
});